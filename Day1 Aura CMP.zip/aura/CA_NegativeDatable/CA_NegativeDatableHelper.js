({
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.callPlannerList");
        var reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse))
        cmp.set("v.callPlannerList", data);
    }, 
    
    getPicklistValues: function(component, event) {
        var action = component.get("c.getEventtypeFieldValue");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var fieldMap = [];
                for(var key in result){
                    fieldMap.push({key: key, value: result[key]});
                }
                component.set("v.fieldMap", fieldMap);
            }
        });
        $A.enqueueAction(action);
    },
    
    sortBy: function (field, reverse, primer) {
        var key = primer ? function(x) {return primer(x[field])} : function(x) {return x[field]};
        //checks if the two rows should switch places
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    
    //Button code
    fetchNegativesAccounts : function( component ) {
        var action = component.get("c.getCallPlannerNegativeRec");
        action.setParams({
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var records =response.getReturnValue();
                component.set("v.callPlannerList", response.getReturnValue());
                records.forEach(function(record){
                    //record.linkName = '/'+record.AccountId__c;
                    record['linkName'] = '/lightning/r/Account/' +record['AccountId__c'] +'/view';
                });
                for ( var i = 0; i < records.length; i++ ) {  
                    if (records[i].Call_Target_Meet__c == 1) {
                        records[i].buttonColor = 'destructive';  
                    }
                    else  
                        records[i].buttonColor = 'destructive-text'; 
                }  
                component.set("v.callPlannerList", records);
            }
        });
        $A.enqueueAction(action);
    },
    
    //Topics code
    getTopicsValues: function(component, event, helper) {
        var action = component.get("c.getPiklistValues");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var result = response.getReturnValue();
                var plValues = [];
                for (var i = 0; i < result.length; i++) {
                    plValues.push({
                        label: result[i],
                        value: result[i]
                    });
                }
                component.set("v.GenreList", plValues);
            }
        });
        $A.enqueueAction(action);
    },
})
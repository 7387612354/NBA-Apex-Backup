({
    saveRecord: function (cmp, event, helper) {
        //Custom validation
        var eventsfields = cmp.find("validate");
        var blank =0;
        if(eventsfields.length !=undefined ){
            var allValid = eventsfields.reduce(function (validSoFar,inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
            if(!allValid){
                blank++;
            }
        }else{
            var allValid=eventsfields;
            if(!allValid.get('v.validity').valid){
                blank++;
            }
        }
        /*validation 2*/
        var eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        if(eventsfields1 == "" || eventsfields1 === undefined || !eventsfields1){
            alert('Contact Name is Mandatory');
            return;
        }
        if(blank == 0 ){
            var action = cmp.get("c.insertEvt");
            //Multislect picklist ; split
            var test =cmp.get("v.selectedGenreList").join('; ');
            action.setParams({
                callPlanRec : JSON.stringify(cmp.get("v.selectesRec")),
                eventsub : cmp.get("v.evtSubject"),
                strtdate : cmp.get("v.evtStart"),
                enddate : cmp.get("v.evtend"),
                eventtype : cmp.get("v.evtType"),
                topics : test,
            });
            
            action.setCallback(this,function(response){
                var state = response.getState();
                if(state === "SUCCESS"){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'Event record has been created successfully.',
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'success',
                        mode: 'pester'
                    });
                    $A.get('e.force:refreshView').fire(); 
                    toastEvent.fire();
                }
                else if(state === "ERROR"){
                    var errors = action.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            alert(errors[0].message);
                        }
                    }
                }
            });       
            $A.enqueueAction(action);
        }
    },
    
    updateColumnSorting: function (cmp, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    },
    
    //Contact lookup mapped start
    handleComponentEvent : function(cmp, event, helper) {
        cmp.set("v.ConId", event.getParam("recordByEventRec"));
        
        var eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        if(eventsfields1 === undefined || eventsfields1 == "" || !eventsfields1){
            alert('Contact Name is Mandatory');
            return;
        }
        var addNewVal = cmp.get('v.selectesRec');
        addNewVal['Doctor_Name__c'] = event.getParam("recordByEventRec").Id;  
        cmp.set('v.selectesRec',addNewVal);
    },
    
    //Contact lookup mapped end
    
    handleRowAction :function(cmp,event,helper){
        //action gives which action performed
        var action = event.getParam('action');
        //row gives complete row information
        var row = event.getParam('row');
        cmp.set('v.selectesRec',row);
       
        cmp.set("v.openModal",true);
        /*Split Code*/
        if(row.Doc1_Available_Datetime__c!=null){
            var splitVal1 = row.Doc1_Available_Datetime__c.replaceAll(" ", "<br/>");
            var  splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP1Val",splitVal01);       
        }
        
        /*Split Code*/ 
        if(row.Doc_2_Available_Datetime__c!=null){
            var splitVal2 = row.Doc_2_Available_Datetime__c.replaceAll(" ", "<br>");
            var  splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP2Val",splitVal01);           
        }
    },
    
    closeModal :function(cmp,event,helper){
        cmp.set("v.openModal",false);
    },
    
    doInit : function(component, event, helper) {
        helper.getPicklistValues(component, event);
        helper.getTopicsValues(component, event);
        component.set('v.mycolumns', [
            {label:'Action',type:  'button',typeAttributes:
             {iconName: 'utility:view',label: 'Schedule',name: 'viewRecord', disabled :false,value: 'viewBtn',variant:{ fieldName: 'buttonColor'}},"initialWidth": 150
            },
            {label: 'Priority', fieldName: 'Priority__c', type: 'Number',sortable: true,"initialWidth": 150},
            {label: 'Account Name', fieldName: 'linkName', type: 'url', 
             typeAttributes: {label: { fieldName: 'Account_Name__c' }, target: '_blank'},"initialWidth": 150},
            {label: 'Last Call Date', fieldName: 'Last_Call_Date_Formula__c', type: 'text', sortable: true,"initialWidth": 150},
            {label: 'Completed Call of This Month', fieldName: 'Call_of_This_Month__c', type: 'Number',sortable: true,"initialWidth": 150},
            {label: 'Incoming Call of This Month', fieldName: 'Incoming_Call_of_This_Month__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Call Frequency', fieldName: 'Call_Frequency_Monthly__c', type: 'Number',sortable: true,"initialWidth": 150},
            {label: 'Segment', fieldName: 'Cataract_Segment__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Procedures', fieldName: 'Medicare_Procedure__c', type: 'Number',sortable: true,"initialWidth": 150},
            {label: 'Predicted Sales(Monthly)', fieldName: 'Predicted_IOL_Sales_Amount__c', type: 'currency',sortable: true,"initialWidth": 150},
            {label: 'Sales(Monthly)', fieldName: 'IOL_sales__c', type: 'currency',sortable: true,"initialWidth": 150},
            {label: 'JnJ Share', fieldName: 'JNJ_IOL_share__c', type: 'Number',sortable: true,"initialWidth": 150},
            {label: 'Dr1', fieldName: 'Available_Doctor_P1__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Available Datetime1', fieldName: 'Doc1_Available_Datetime__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Dr2', fieldName: 'Available_Doctor_P2__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Available Datetime2', fieldName: 'Doc_2_Available_Datetime__c', type: 'text',sortable: true,"initialWidth": 150},
            {label: 'Address', fieldName: 'Account_Addess__c', type: 'text',sortable: true,"initialWidth": 150},
        ]);
            helper.fetchNegativesAccounts( component );  
            },
            //handle Event type Picklist Selection
            handleOnChange : function(component, event, helper) {
            var EventType = component.get("v.evtType");
            },
            //Topics code
            handleGenreChange: function (component, event, helper) {
            //Get the Selected values   
            var selectedValues = component.get("v.selectedGenreList");
            //Update the Selected Values  
            component.set("v.selectedGenreList", selectedValues);
            },
            
            /*StartdateUpdate validation*/
            /*call dateUpdate function on onchange event on date field*/ 
            StartdateUpdate : function(component, event, helper) {
            
            var today = new Date();        
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            // if date is less then 10, then append 0 before date   
            if(dd < 10){
            dd = '0' + dd;
            } 
            // if month is less then 10, then append 0 before date    
            if(mm < 10){
            mm = '0' + mm;
            }
            
            var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
            if(component.get("v.evtStart") != '' && component.get("v.evtStart") < todayFormattedDate){
            component.set("v.dateValidationError" , true);
            }else{
            component.set("v.dateValidationError" , false);
            }
            },
            
            /*EnddateUpdate validation*/
            EnddateUpdate: function(component, event, helper) {
            
            var today = new Date();        
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            // if date is less then 10, then append 0 before date   
            if(dd < 10){
            dd = '0' + dd;
            } 
            // if month is less then 10, then append 0 before date    
            if(mm < 10){
            mm = '0' + mm;
            }
            
            var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
            if((component.get("v.evtend") != '' && component.get("v.evtend") < todayFormattedDate) || component.get("v.evtend") <= component.get("v.evtStart")){
            component.set("v.dateValidationError1" , true);
            }else{
            component.set("v.dateValidationError1" , false);
            }
            
            },
            
            })
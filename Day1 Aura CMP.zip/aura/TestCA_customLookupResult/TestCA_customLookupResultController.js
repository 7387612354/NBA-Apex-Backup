({
  selectRecord : function(component, event, helper){      
      var getSelectRecord = component.get("v.oRecord");
      //alert('inside child lookup cmp'+ getSelectRecord);
      var compEvent = component.getEvent("oSelectedRecordEvent");
         compEvent.setParams({"recordByEvent" : getSelectRecord,
                              "recordByEventRec": getSelectRecord});  
         compEvent.fire();
    },
})
# JJSV - Eyeforce Call Automation Project - Japanese translation for Phaco NBA & Call planning page, Phaco NBA logic changes.

#### 1. Functionality:

| User story # | Description |

| ADXU-16340 | Phaco NBA Flows translation|
| ADXU-15709 | JNJ call planning page translation|
| ADXU-16064 | Column concatination on datatable call planning page|
| ADXU-16363 | Phaco NBA Logic Changes|

#### 2. Functionality Design Goals:

1)To translate the field labels, field values and the flow details to Japanese language.
2)To translate the field labels,columns, field values in Call planning page to Japanese language.
3)Column concatination on datatable call planning page.
4)Phaco NBA Logic Changes: 
    For expiring asset NBA - expired asset and oppty closeddate should be greater than 1 year in past/future. and for open oppty created date should be 1 year more in past then only NBA will appear.
    For Opportunity creation - event should be valide and closeddate should be greater than 1 year in past/future. and for open oppty created date should be 1 year more in past then only NBA will appear.


#### 3. Design Details:

The filter condition will be included in the Apex/Aura component logic besed on jira storiess.


#### 4. Components List:

| Component Type | Name | Comments | 
|:--- |:--- |:--- |:--- |
| Component | CA_PositiveDatable | Translation for positive Account datatable |
| Component | CA_NegativeDatable | Translation for Negative Account datatable |
| Component | Custom_Calendar_CMP | Translation for custom calendar |
| Component | CA_EventPopUp_CMP | Translation for Event Popup layout |
| Apex | RecommendationUtils_CA | Phaco Product logic aadded |
| Apex | OpportunitiesSelector_CA | fetch opportunity with phaco products and based on jira stories added filter conditions |
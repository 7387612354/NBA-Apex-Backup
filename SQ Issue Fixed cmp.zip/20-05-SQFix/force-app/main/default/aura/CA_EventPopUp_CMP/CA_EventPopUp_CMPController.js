({
    successShowtoast: function (cmp, event, helper)
    {
        let action = cmp.get("c.insertEvt");
        let test = cmp.get("v.selectedGenreList").join('; ');
        let isDateError = cmp.get("v.dateValidationError");
        let isDateError1 = cmp.get("v.dateValidationError1");
        if(isDateError != true && isDateError1 != true)
        {
            action.setParams({
                callPlanRec: JSON.stringify(cmp.get("v.selectesRec")),
                eventsub: cmp.get("v.evtSubject"),
                strtdate: cmp.get("v.evtStart"),
                enddate: cmp.get("v.evtend"),
                eventtype: cmp.get("v.evtType"),
                Field2: cmp.get("v.PurposeForVisiting"),
                Anticipatedques: cmp.get("v.anticipatedquestions"),
                salesTools: cmp.get("v.salesTools"),
                Field3: cmp.get("v.advancepreparation"),
                topics: test
            });
            action.setCallback(this, function (response) {
                let state = response.getState();
                let toastEvent = $A.get("e.force:showToast");
                if (state === "SUCCESS")
                {
                    let staticLabel = $A.get("$Label.c.CA_Save_Toast_Msg");
                    toastEvent.setParams({
                        title: 'Success',
                        message: staticLabel,
                        duration: ' 5000',
                        key: 'info_alt',
                        type: 'success',
                        mode: 'pester'
                    });
                    $A.get('e.force:refreshView').fire();
                }
                else if (state === "ERROR")
                {
                    let errors = action.getError();
                    toastEvent.setParams({
                        title: 'Error',
                        message: errors[0].message,
                        type: 'error'
                    });
                    $A.get('e.force:refreshView').fire();
                }
                toastEvent.fire();
            });
            $A.enqueueAction(action);
        }
    },
    saveRecord: function (cmp, event, helper)
    {
        /*
         * custom validation for Event popup layout
        */
        let eventsfields = cmp.find("validate");
        let blank = 0;
        if (eventsfields.length != undefined )
        {
            let allValid = eventsfields.reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
            if (!allValid)
            {
                blank++;
            }
        } 
        else
        {
            let allValid = eventsfields;
            if (!allValid.get('v.validity').valid)
            {
                blank++;
            }
        }
        /* 
         * custom validation for Contact Name from Event popup layout
        */
        let eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        if (eventsfields1 == "" || eventsfields1 === undefined || !eventsfields1)
        {
            let toastEvent = $A.get("e.force:showToast");
            let staticLab = $A.get("$Label.c.CA_Contact_Mandatory_Label");
            toastEvent.setParams({
                message: staticLab,
                key: 'info_alt',
                type: 'warning',
            });
            toastEvent.fire();
            return;
        }
        if (blank == 0)
        { 
            let successMethod =cmp.get('c.successShowtoast');
            $A.enqueueAction(successMethod);
        }
    },  
    /* 
   	* Contact Lookup mapping on Event Popup layout
  	*/
    handleComponentEvent: function (cmp, event, helper)
    {
        cmp.set("v.ConId", event.getParam("recordByEventRec"));
        let addNewVal = cmp.get('v.selectesRec');
        addNewVal['Doctor_Name__c'] = event.getParam("recordByEventRec").Id;
        let eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        let acc=cmp.get('v.selectesRec.Account_Name__c');
        let connm = cmp.get('v.selectedLookUpRecord.Name');
        let accNameConcat =acc+'  '+'-'+'  '+ connm;
        cmp.set('v.evtSubject',accNameConcat);
        if (eventsfields1 === undefined || eventsfields1 == "" || !eventsfields1)
        {
            return;
        }
        cmp.set('v.selectesRec', addNewVal);
    },
    closeModal: function (cmp, event, helper)
    {
        cmp.set("v.openModal", false);
        $A.get('e.force:refreshView').fire();
    },
    doInit: function (component, event, helper)
    {
        let acc=component.get('v.selectesRec.Account_Name__c');
        let accNameConcat =acc+ '  -';
        component.set('v.evtSubject',accNameConcat);
        let staticLabel = $A.get("$Label.c.CA_Calendar_Details_Label");
        component.set("v.mylabel1", staticLabel);
        let staticLabel2 = $A.get("$Label.c.CA_New_Event_Label");
        component.set("v.CA_New_Event_Label", staticLabel2);
        let staticLabel3 = $A.get("$Label.c.CA_AccountName_Label");
        component.set("v.CA_AccountName_Label", staticLabel3);
        let staticLabel4 =$A.get("$Label.c.CA_AvailableDatetime1_Label");
        component.set("v.CA_AvailableDatetime1_Label",staticLabel4);
        let staticLabel5 =$A.get("$Label.c.CA_Available_Datetime2_Header_Label");
        component.set("v.CA_Available_Datetime2_Header_Label",staticLabel5);
        let staticLabel1 = $A.get("$Label.c.CA_EventPOPup_Label");
        component.set("v.mylabel2", staticLabel1);
        let today = new Date()
        let tomorrow  = new Date();
        tomorrow.setDate(today.getDate() + 1);
        component.set('v.evtStart', tomorrow.toISOString());
        let todayend  = new Date();
        let tomorrowend  = new Date();
        tomorrowend.setDate(todayend.getDate() + 1);
        tomorrowend.setHours(todayend.getHours() + 1);
        component.set('v.evtend', tomorrowend.toISOString());
        let row = component.get('v.selectesRec');
        /*
     	* Available Datetime1 Split Code
    	*/
        if (row.Doc1_Available_Datetime__c != null)
        {
            let splitVal1 = row.Doc1_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            component.set("v.availDTP1Val", splitVal01);
        }
        /*
     	* Available Datetime2 Split Code
    	*/
        if (row.Doc_2_Available_Datetime__c != null)
        {
            let splitVal2 = row.Doc_2_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal2.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            component.set("v.availDTP2Val", splitVal01);
        }
        helper.getPicklistValues(component, event);
        helper.getTopicsValues(component, event);
        helper.fetchPosAccounts(component);
    },
    /*
   	* handle other Topics covered multi-Picklist Selection on Event Popup Layout
  	*/
    handleGenreChange: function (component, event, helper)
    {
        let selectedValues = component.get("v.selectedGenreList");
        component.set("v.selectedGenreList", selectedValues);
    },
    /*
   	* Event StartDateTime custom validation on Event Popup Layout
 	*/
    StartdateUpdate: function (component, event, helper)
    {
        let staticLabel = $A.get("$Label.c.CA_StartDateValidation_label");
        component.set("v.CA_StartDateValidation_label", staticLabel);
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();
        let srtvar =component.get('v.evtStart');
        let srtvar1 = new Date(srtvar);
        srtvar1.setHours( srtvar1.getHours() + 1 );
        component.set('v.evtend', srtvar1.toISOString());
        if (dd < 10)
        {
            dd = '0' + dd;
        }
        if (mm < 10)
        {
            mm = '0' + mm;
        }
        let todayFormattedDate = yyyy + '-' + mm + '-' + dd;
        if (component.get("v.evtStart") != '' && component.get("v.evtStart") < todayFormattedDate)
        {
            component.set("v.dateValidationError", true);
        } 
        else
        {
            component.set("v.dateValidationError", false);
        }
    },
    /*
     * Event EndDateTime custom validation on Event Popup Layout
    */
    EnddateUpdate: function (component, event, helper)
    {
        
        let staticLabel = $A.get("$Label.c.CA_CA_EndDateValidation_label");
        component.set("v.CA_EndDateValidation_label", staticLabel);
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();
        if (dd < 10)
        {
            dd = '0' + dd;
        }
        if (mm < 10)
        {
            mm = '0' + mm;
        }
        let todayFormattedDate = yyyy + '-' + mm + '-' + dd;
        if ((component.get("v.evtend") != '' && component.get("v.evtend") < todayFormattedDate) || component.get("v.evtend") <= component.get("v.evtStart"))
        {
            component.set("v.dateValidationError1", true);
        } 
        else
        {
            component.set("v.dateValidationError1", false);
        }
    }
});
({
    updateColumnSorting: function (cmp, event, helper)
    {
        let fieldName = event.getParam('fieldName');
        let sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    },
    
    handleRowAction: function (cmp, event, helper)
    {
        let row = event.getParam('row');
        cmp.set('v.selectesRec', row);
        cmp.set("v.openModal", true);
        /*
     	* Available Datetime1 Split Code
    	*/
        if (row.Doc1_Available_Datetime__c != null)
        {
            let splitVal1 = row.Doc1_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP1Val", splitVal01);
        }
        /*
     	* Available Datetime2 Split Code
    	*/
        if (row.Doc_2_Available_Datetime__c != null)
        {
            let splitVal2 = row.Doc_2_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal2.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP2Val", splitVal01);
        }
    },
    
    doInit: function (component, event, helper)
    {
		let staticLabel1 = $A.get("$Label.c.CA_Positive_Header");
        let staticLabel2 = $A.get("$Label.c.CA_ScheduleButton");
        let staticLabel3 = $A.get("$Label.c.CA_ActionHeader");
        let staticLabel4 = $A.get("$Label.c.CA_Priority_Do_Not_Visit_Flag_Neg_Header");
        let staticLabel5 = $A.get("$Label.c.CA_Account_Name_Header_Label");
        let staticLabel6 = $A.get("$Label.c.CA_Last_Call_Date_Header_Label");
        let staticLabel7 = $A.get("$Label.c.CA_Completed_Call_of_this_Month_Header_Label");
        let staticLabel8 = $A.get("$Label.c.CA_Call_Frequency_Header_Label");
        let staticLabel_Tar = $A.get("$Label.c.CA_Target_in_3_month_Header_Label");
        let staticLabel_Salesplan = $A.get("$Label.c.CA_Target_Month_Sales_Plan_Unit_Header_Label");
        let staticLabel_potential = $A.get("$Label.c.CA_Predicted_Potential_Monthly_Header_Label");
        let staticLabel11 = $A.get("$Label.c.CA_Segment_Header_Label");
        let staticLabel12 = $A.get("$Label.c.CA_Procedures_Header_Label");
        let staticLabel_SalesMonthly = $A.get("$Label.c.CA_Sales_In_Unit_Monthly_Header_Label");
        let staticLabel13 = $A.get("$Label.c.CA_JnJ_Share_Header_Label");
        let staticLabel_PlanProd = $A.get("$Label.c.CA_Plan_To_Use_All_JnJ_Prod_Header_Label");
        let staticLabel14 = $A.get("$Label.c.CA_Dr1_Header_Label");
		let staticLabel15 = $A.get("$Label.c.CA_Available_Datetime1_Header_Label");
		let staticLabel16 = $A.get("$Label.c.CA_Dr2_Header_Label");
		let staticLabel17 = $A.get("$Label.c.CA_Available_Datetime2_Header_Label");
		let staticLabel18 = $A.get("$Label.c.CA_Address_Header_Label");
        
        component.set("v.CA_Positive_Header", staticLabel1);
        component.set('v.accName', 'selectesRec.AccountId__c');
        component.set('v.mycolumns', [
            {
                label: staticLabel3,
                type: 'button',
                typeAttributes:
                {
                    iconName: 'utility:view',
                    label: staticLabel2,
                    name: 'viewRecord',
                    disabled: false,
                    value: 'viewBtn',
                    variant: { fieldName: 'buttonColor' }
                },
                "initialWidth": 150
            },
            {
                label: staticLabel4,
                fieldName: 'Concate_Priority_and_Do_not_Visit_Flag__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel5,
                fieldName: 'linkName',
                type: 'url',
                typeAttributes: {
                    label: { fieldName: 'Account_Name__c' },
                    target: '_blank'
                },
                "initialWidth": 150
            },
            {
                label: staticLabel6,
                fieldName: 'Last_Call_Date_Formula__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel7,
                fieldName: 'concate_Completed_Call_and_Incoming_Call__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel8,
                fieldName: 'Call_Frequency_Monthly__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel_Tar,
                fieldName: 'Target_in_3_month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel_Salesplan,
                fieldName: 'Target_month_Sales_plan_unit__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel_potential,
                fieldName: 'Predicted_Account_fulfillment__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel11,
                fieldName: 'Cataract_Segment__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel12,
                fieldName: 'Medicare_Procedure__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel_SalesMonthly,
                fieldName: 'Account_Potential__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel13,
                fieldName: 'JNJ_IOL_share__c',
                type: 'percent',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel_PlanProd,
                fieldName: 'Plan_to_use_all_JnJ_Prod__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel14,
                fieldName: 'Available_Doctor_P1__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel15,
                fieldName: 'Doc1_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel16,
                fieldName: 'Available_Doctor_P2__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel17,
                fieldName: 'Doc_2_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: staticLabel18,
                fieldName: 'Account_Addess__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            }
        ]);
        helper.fetchPosAccounts(component);
    },
});
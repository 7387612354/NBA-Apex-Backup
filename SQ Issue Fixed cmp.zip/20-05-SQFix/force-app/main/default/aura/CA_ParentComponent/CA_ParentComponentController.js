({
    onfocus : function(component,event,helper)
    {
        $A.util.addClass(component.find("mySpinner"), "slds-show");
        let forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        let getInputkeyWord = '';
        helper.searchHelper(component,event,getInputkeyWord);
    },
    onblur : function(component,event,helper)
    {      
        component.set("v.listOfSearchRecords", null );
        let forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressController : function(component, event, helper)
    {
        let getInputkeyWord = component.get("v.SearchKeyWord");
        if( getInputkeyWord.length > 0 )
        {
            let forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else
        {  
            component.set("v.listOfSearchRecords", null );
            let forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },
    clear :function(component,event,heplper)
    {
        let pillTarget = component.find("lookup-pill");
        let lookUpTarget = component.find("lookupField");
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
        component.set("v.selectedRecord", {} );
    },
    handleComponentEvent : function(component, event, helper)
    {
        let selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.selectedRecord" , selectedAccountGetFromEvent);
        let objName = component.get('v.objectAPIName')
        if(objName =="Contact")
        {
            component.set("v.ConId",component.get('v.selectedRecord.Id'));
        }
        let forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        let forclose1 = component.find("searchRes");
        $A.util.addClass(forclose1, 'slds-is-close');
        $A.util.removeClass(forclose1, 'slds-is-open'); 
        let lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');
    },
})
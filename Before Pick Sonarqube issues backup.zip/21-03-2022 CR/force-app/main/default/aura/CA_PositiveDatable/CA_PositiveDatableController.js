({
    successShowtoast: function (cmp, event, helper)
    {
        let action = cmp.get("c.insertEvt");
        let test = cmp.get("v.selectedGenreList").join('; ');
        
        action.setParams({
            callPlanRec: JSON.stringify(cmp.get("v.selectesRec")),
            eventsub: cmp.get("v.evtSubject"),
            strtdate: cmp.get("v.evtStart"),
            enddate: cmp.get("v.evtend"),
            eventtype: cmp.get("v.evtType"),
            topics: test
        });
        action.setCallback(this, function (response) {
            let state = response.getState();
            let toastEvent = $A.get("e.force:showToast");
            if (state === "SUCCESS") 
            {
                toastEvent.setParams({
                    title: 'Success',
                    message: 'Event record has been created successfully.',
                    duration: ' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'pester'
                });
                
                $A.get('e.force:refreshView').fire();
            } 
            else if (state === "ERROR") 
            {
                let errors = action.getError();
                toastEvent.setParams({
                    title: 'Error',
                    message: errors[0].message,
                    type: 'error'
                });
                $A.get('e.force:refreshView').fire();
            }
            toastEvent.fire();
        });
        $A.enqueueAction(action);
    },
    
    saveRecord: function (cmp, event, helper) 
    {
        /* 
         * custom validation for Event popup layout
        */
        let eventsfields = cmp.find("validate");
        let blank = 0;
        if (eventsfields.length != undefined) 
        {
            let allValid = eventsfields.reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
            if (!allValid) 
            {
                blank++;
            }
        } 
        else 
        {
            let allValid = eventsfields;
            if (!allValid.get('v.validity').valid)
            {
                blank++;
            }
        }
        /* 
         * custom validation for Contact Name from Event popup layout
        */
        let eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        if (eventsfields1 == "" || eventsfields1 === undefined || !eventsfields1) 
        {
            let toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Warning',
                message: 'Contact Name is Mandatory',
                key: 'info_alt',
                type: 'warning',
            });
            toastEvent.fire();
            return;
        }
        if (blank == 0) 
        {
            let successMethod =cmp.get('c.successShowtoast');
            $A.enqueueAction(successMethod);
        }
    },
    
    updateColumnSorting: function (cmp, event, helper)
    {
        let fieldName = event.getParam('fieldName');
        let sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    },
    
    /* 
   	* Contact Lookup mapping on Event Popup layout
  	*/
    handleComponentEvent: function (cmp, event, helper) 
    {
        cmp.set("v.ConId", event.getParam("recordByEventRec"));
        let addNewVal = cmp.get('v.selectesRec');
        addNewVal['Doctor_Name__c'] = event.getParam("recordByEventRec").Id;
        let eventsfields1 = cmp.get('v.selectedLookUpRecord.Id');
        if (eventsfields1 === undefined || eventsfields1 == "" || !eventsfields1) 
        {
            return;
        }
        cmp.set('v.selectesRec', addNewVal);
    },
    
    handleRowAction: function (cmp, event, helper) 
    {
        let row = event.getParam('row');
        cmp.set('v.selectesRec', row);
        cmp.set("v.openModal", true);
        
        /*
     	* Available Datetime1 Split Code
    	*/
        if (row.Doc1_Available_Datetime__c != null) 
        {
            let splitVal1 = row.Doc1_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP1Val", splitVal01);
        }
        /*
     	* Available Datetime2 Split Code
    	*/
        if (row.Doc_2_Available_Datetime__c != null) 
        {
            let splitVal2 = row.Doc_2_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal2.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP2Val", splitVal01);
        }
    },
    
    closeModal: function (cmp, event, helper) 
    {
        cmp.set("v.openModal", false);
    },
    
    doInit: function (component, event, helper) 
    {
        component.set('v.accName', 'selectesRec.AccountId__c');
        
        helper.getPicklistValues(component, event);
        helper.getTopicsValues(component, event);
        component.set('v.mycolumns', [
            {
                label: 'Action',
                type: 'button',
                typeAttributes:
                {
                    iconName: 'utility:view',
                    label: 'Schedule',
                    name: 'viewRecord',
                    disabled: false,
                    value: 'viewBtn',
                    variant: { fieldName: 'buttonColor' }
                },
                "initialWidth": 150
            },
            {
                label: 'Priority',
                fieldName: 'Priority__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Account Name',
                fieldName: 'linkName',
                type: 'url',
                typeAttributes: {
                    label: { fieldName: 'Account_Name__c' },
                    target: '_blank'
                },
                "initialWidth": 150
            },
            {
                label: 'Last Call Date',
                fieldName: 'Last_Call_Date_Formula__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Completed Call of This Month',
                fieldName: 'Call_of_This_Month__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Incoming Call of This Month',
                fieldName: 'Incoming_Call_of_This_Month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Call Frequency',
                fieldName: 'Call_Frequency_Monthly__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Target in 3 month',
                fieldName: 'Target_in_3_month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Segment',
                fieldName: 'Cataract_Segment__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Procedures',
                fieldName: 'Medicare_Procedure__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Predicted Potential(Monthly)',
                fieldName: 'Predicted_Account_fulfillment__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Sales In Unit (Monthly)',
                fieldName: 'Account_Potential__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Target month Sales plan unit',
                fieldName: 'Target_month_Sales_plan_unit__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'JnJ Share',
                fieldName: 'JNJ_IOL_share__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Plan to use all JnJ Prod',
                fieldName: 'Plan_to_use_all_JnJ_Prod__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Dr1',
                fieldName: 'Available_Doctor_P1__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Available Datetime1',
                fieldName: 'Doc1_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Dr2',
                fieldName: 'Available_Doctor_P2__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Available Datetime2',
                fieldName: 'Doc_2_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Address',
                fieldName: 'Account_Addess__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            }
            
        ]);
        helper.fetchPosAccounts(component);
    },
    
    /*
   	* handle other Topics covered multi-Picklist Selection on Event Popup Layout
  	*/
    handleGenreChange: function (component, event, helper) 
    {
        let selectedValues = component.get("v.selectedGenreList");
        component.set("v.selectedGenreList", selectedValues);
    },
    
    /*
   	* Event StartDateTime custom validation on Event Popup Layout
 	*/
    StartdateUpdate: function (component, event, helper)
    {
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();
        if (dd < 10) 
        {
            dd = '0' + dd;
        }
        if (mm < 10)
        {
            mm = '0' + mm;
        }
        
        let todayFormattedDate = yyyy + '-' + mm + '-' + dd;
        if (component.get("v.evtStart") != '' && component.get("v.evtStart") < todayFormattedDate) 
        {
            component.set("v.dateValidationError", true);
        } 
        else 
        {
            component.set("v.dateValidationError", false);
        }
    },
    
    /*
     * Event EndDateTime custom validation on Event Popup Layout
    */
    EnddateUpdate: function (component, event, helper) 
    {
        
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();
        if (dd < 10)
        {
            dd = '0' + dd;
        }
        if (mm < 10) 
        {
            mm = '0' + mm;
        }
        
        let todayFormattedDate = yyyy + '-' + mm + '-' + dd;
        if ((component.get("v.evtend") != '' && component.get("v.evtend") < todayFormattedDate) || component.get("v.evtend") <= component.get("v.evtStart")) 
        {
            component.set("v.dateValidationError1", true);
        } 
        else 
        {
            component.set("v.dateValidationError1", false);
        }
    }
});
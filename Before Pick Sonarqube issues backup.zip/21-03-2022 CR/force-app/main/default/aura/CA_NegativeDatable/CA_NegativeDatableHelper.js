({
    sortData: function (cmp, fieldName, sortDirection) 
    {
        let data = cmp.get("v.callPlannerList");
        let reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse));
        cmp.set("v.callPlannerList", data);
    },
    
    getPicklistValues: function (component, event) 
    {
        let action = component.get("c.getEventtypeFieldValue");
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS") 
            {
                let result = response.getReturnValue();
                let fieldMap = [];
                for (let key in result)
                {
                     if (result.hasOwnProperty(key))
                     {
                        fieldMap.push({
                        key: key,
                        value: result[key]
                        });
                     }
                }
                component.set("v.fieldMap", fieldMap);
            }
            else if (state === "ERROR") 
            {
                let errors = response.getError();
                if (errors) 
                {
                    if (errors[0] && errors[0].message) 
                    {
                        $A.log("Errors", errors);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    sortBy: function (field, reverse, primer) 
    {
        let key = primer ? function (x) {
            return primer(x[field]);
        } : function (x) {
            return x[field];
        };
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        };
    },
    
    fetchNegativesAccounts: function (component) 
    {
        let action = component.get("c.getCallPlannerNegativeRec");
        action.setParams({});
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS") 
            {
                let records = response.getReturnValue();
                component.set("v.callPlannerList", response.getReturnValue());
                records.forEach(function (record) {
                    record['linkName'] = '/lightning/r/Account/' + record['AccountId__c'] + '/view';
                });
                for (let i = 0; i < records.length; i++) 
                {
                    if (records[i].Call_Target_Meet__c == 1) 
                    {
                        records[i].buttonColor = 'destructive';
                    } 
                    else 
                    {
                        records[i].buttonColor = 'destructive-text';
                    }
                }
                component.set("v.callPlannerList", records);
            }
            else if (state === "ERROR") 
            {
                let errors = response.getError();
                if (errors) 
                {
                    if (errors[0] && errors[0].message) 
                    {
                        $A.log("Errors", errors);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getTopicsValues: function (component, event, helper) 
    {
        let action = component.get("c.getPiklistValues");
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS") 
            {
                let result = response.getReturnValue();
                let plValues = [];
                for (let i = 0; i < result.length; i++)
                {
                    plValues.push({
                        label: result[i],
                        value: result[i]
                    });
                }
                component.set("v.GenreList", plValues);
            } 
            else if (state === "ERROR") 
            {
                let errors = response.getError();
                if (errors) 
                {
                    if (errors[0] && errors[0].message) 
                    {
                        $A.log("Errors", errors);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
})
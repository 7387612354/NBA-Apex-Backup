<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CA Japan NBA</label>
    <protected>false</protected>
    <values>
        <field>Account_Status__c</field>
        <value xsi:type="xsd:string">Active,Opeあり,Opeあり 件数不明</value>
    </values>
    <values>
        <field>Asset_Age_Calculator__c</field>
        <value xsi:type="xsd:double">7.0</value>
    </values>
    <values>
        <field>Asset_Record_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Asset_Status__c</field>
        <value xsi:type="xsd:string">Active</value>
    </values>
    <values>
        <field>Close_Days_1__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Close_Days_2__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Closed_Oppty__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Einstein_NBA_Flag__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Event_Filter__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Event_Region__c</field>
        <value xsi:type="xsd:string">JPAN</value>
    </values>
    <values>
        <field>High_Activity_Days__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>High_Modified_Days__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>High_Potential_Segments__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Invalid_Vcode__c</field>
        <value xsi:type="xsd:string">invalid</value>
    </values>
    <values>
        <field>Low_Activity_Days__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Low_Modified_Days__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Low_Potential_Segments__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Open_Oppty__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Oppty_RecordTypeName__c</field>
        <value xsi:type="xsd:string">Standard Opportunity</value>
    </values>
    <values>
        <field>ProductFamily__c</field>
        <value xsi:type="xsd:string">PHACO EQUIPMENT</value>
    </values>
    <values>
        <field>Record_Type_Name__c</field>
        <value xsi:type="xsd:string">Customer Account</value>
    </values>
    <values>
        <field>Region_Filter__c</field>
        <value xsi:type="xsd:string">JAPN</value>
    </values>
    <values>
        <field>Stage_Filter__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Visit_Result__c</field>
        <value xsi:nil="true"/>
    </values>
</CustomMetadata>

({
    negupdateColumnSorting: function (cmp, event, helper)
    {
        let fieldName = event.getParam('fieldName');
        let sortDirection = event.getParam('sortDirection');
        cmp.set("v.negsortedBy", fieldName);
        cmp.set("v.negsortedDirection", sortDirection);
        helper.negsortData(cmp, fieldName, sortDirection);
    },
    neghandleRowAction: function (cmp, event, helper)
    {
        let row = event.getParam('row');
        cmp.set('v.selectesRec', row);
        cmp.set("v.openModal", true);
    },
    
    doInit: function (cmp, event, helper)
    {
        cmp.set('v.accName', 'selectesRec.AccountId__c');
        cmp.set('v.negmycolumns', [
            {
                label: 'Action',
                type: 'button',
                typeAttributes:
                {
                    iconName: 'utility:view',
                    label: 'Schedule',
                    name: 'viewNegRecord',
                    disabled: false,
                    value: 'viewBtn',
                    variant: { fieldName: 'negbuttonColor' }
                },
                "initialWidth": 155
            },
            {
                label: 'Priority ',
                fieldName: 'Priority__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Account Name ',
                fieldName: 'linkName',
                type: 'url',
                typeAttributes: {
                    label: { fieldName: 'Account_Name__c' },
                    target: '_blank'
                },
                "initialWidth": 155
            },
            {
                label: 'Last Call Date ',
                fieldName: 'Last_Call_Date_Formula__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Completed Call of This Month ',
                fieldName: 'Call_of_This_Month__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Incoming Call of This Month ',
                fieldName: 'Incoming_Call_of_This_Month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Call Frequency ',
                fieldName: 'Call_Frequency_Monthly__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Segment ',
                fieldName: 'Cataract_Segment__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Procedures ',
                fieldName: 'Medicare_Procedure__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Predicted Sales(Monthly) ',
                fieldName: 'Predicted_IOL_Sales_Amount__c',
                type: 'currency',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Sales(Monthly) ',
                fieldName: 'IOL_sales__c',
                type: 'currency',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'JnJ Share ',
                fieldName: 'JNJ_IOL_share__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Dr1 ',
                fieldName: 'Available_Doctor_P1__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Available Datetime1 ',
                fieldName: 'Doc1_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Dr2 ',
                fieldName: 'Available_Doctor_P2__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Available Datetime2 ',
                fieldName: 'Doc_2_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: 'Address ',
                fieldName: 'Account_Addess__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            }
        ]);
        helper.fetchNegativesAccounts(cmp);
    },
});
({
    getPicklistValues: function (component, event)
    {
        let action = component.get("c.getEventtypeFieldValue");
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS")
            {
                let result = response.getReturnValue();
                let fieldMap = [];
                for (let key in result)
                {
                    if (result.hasOwnProperty(key))
                    {
                    	fieldMap.push({
                        key: key,
                        value: result[key]
                    	});
                    }
                }
                component.set("v.fieldMap", fieldMap);
            } 
            else if (state === "ERROR")
            {
                let errors = response.getError();
                if (errors)
                {
                    $A.log("Errors", errors[0].message);
                }
            }
        });
        $A.enqueueAction(action);
    },
 
    fetchPosAccounts: function (component)
    {
        let action = component.get("c.getCallPlannerRec");
        action.setParams({});
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS")
            {
                let records = response.getReturnValue();
                component.set("v.callPlannerList", response.getReturnValue());
                records.forEach(function (record) {
                    record['linkName'] = '/lightning/r/Account/' + record['AccountId__c'] + '/view';
                });
                for (let i = 0; i < records.length; i++)
                {
                    if (records[i].Call_Target_Meet__c == 1)
                    {
                        records[i].buttonColor = 'destructive';
                    }
                    else
                    {
                        records[i].buttonColor = 'destructive-text';
                    }
                }
                component.set("v.callPlannerList", records);
            } 
            else if (state === "ERROR")
            {
                let errors = response.getError();
                if (errors)
                {
                    $A.log("Errors", errors[0].message);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getTopicsValues: function (component, event, helper)
    {
        let action = component.get("c.getPiklistValues");
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS")
            {
                let result = response.getReturnValue();
                let plValues = [];
                for (let i = 0; i < result.length; i++)
                {
                    plValues.push({
                        label: result[i],
                        value: result[i]
                    });
                }
                component.set("v.GenreList", plValues);
            } 
            else if (state === "ERROR")
            {
                let errors = response.getError();
                if (errors)
                {
                    $A.log("Errors", errors[0].message);
                }
            }
        });
        $A.enqueueAction(action);
    },
})
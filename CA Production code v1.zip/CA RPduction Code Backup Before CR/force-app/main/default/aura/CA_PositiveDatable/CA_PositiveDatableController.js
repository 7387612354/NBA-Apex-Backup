({
    updateColumnSorting: function (cmp, event, helper)
    {
        let fieldName = event.getParam('fieldName');
        let sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    },
    
    handleRowAction: function (cmp, event, helper)
    {
        let row = event.getParam('row');
        cmp.set('v.selectesRec', row);
        cmp.set("v.openModal", true);
        /*
     	* Available Datetime1 Split Code
    	*/
        if (row.Doc1_Available_Datetime__c != null)
        {
            let splitVal1 = row.Doc1_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal1.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP1Val", splitVal01);
        }
        /*
     	* Available Datetime2 Split Code
    	*/
        if (row.Doc_2_Available_Datetime__c != null)
        {
            let splitVal2 = row.Doc_2_Available_Datetime__c.replaceAll(" ", "<br/>");
            let splitVal01 = splitVal2.replace(/(<br\s*\/?>){2,}/gi, '<br>');
            cmp.set("v.availDTP2Val", splitVal01);
        }
    },
    
    doInit: function (component, event, helper)
    {
        component.set('v.accName', 'selectesRec.AccountId__c');
        component.set('v.mycolumns', [
            {
                label: 'Action',
                type: 'button',
                typeAttributes:
                {
                    iconName: 'utility:view',
                    label: 'Schedule',
                    name: 'viewRecord',
                    disabled: false,
                    value: 'viewBtn',
                    variant: { fieldName: 'buttonColor' }
                },
                "initialWidth": 150
            },
            {
                label: 'Priority',
                fieldName: 'Priority__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Account Name',
                fieldName: 'linkName',
                type: 'url',
                typeAttributes: {
                    label: { fieldName: 'Account_Name__c' },
                    target: '_blank'
                },
                "initialWidth": 150
            },
            {
                label: 'Last Call Date',
                fieldName: 'Last_Call_Date_Formula__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Completed Call of This Month',
                fieldName: 'Call_of_This_Month__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Incoming Call of This Month',
                fieldName: 'Incoming_Call_of_This_Month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Call Frequency',
                fieldName: 'Call_Frequency_Monthly__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Target in 3 month',
                fieldName: 'Target_in_3_month__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Segment',
                fieldName: 'Cataract_Segment__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Procedures',
                fieldName: 'Medicare_Procedure__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Predicted Potential(Monthly)',
                fieldName: 'Predicted_Account_fulfillment__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Sales In Unit (Monthly)',
                fieldName: 'Account_Potential__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Target month Sales plan unit',
                fieldName: 'Target_month_Sales_plan_unit__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'JnJ Share',
                fieldName: 'JNJ_IOL_share__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Plan to use all JnJ Prod',
                fieldName: 'Plan_to_use_all_JnJ_Prod__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Dr1',
                fieldName: 'Available_Doctor_P1__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Available Datetime1',
                fieldName: 'Doc1_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Dr2',
                fieldName: 'Available_Doctor_P2__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Available Datetime2',
                fieldName: 'Doc_2_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            },
            {
                label: 'Address',
                fieldName: 'Account_Addess__c',
                type: 'text',
                sortable: true,
                "initialWidth": 150
            }
            
        ]);
        helper.fetchPosAccounts(component);
    },
});